GraphQL Server Demo Project
============================

Project demonstrates how to implement GraphQL API server based on Yii2 PHP framework.

https://habrahabr.ru/post/336758/